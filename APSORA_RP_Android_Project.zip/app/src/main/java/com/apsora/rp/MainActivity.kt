package com.apsora.rp

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.documentfile.provider.DocumentFile

class MainActivity : Activity() {
    companion object {
        private const val PREFS = "apsora_preferences"
        private const val KEY_PLAYER = "player_name"
        private const val KEY_MODS_URI = "mods_folder_uri"
        private const val REQUEST_MODS_FOLDER = 4102

        // Set this to the real package ID of the SA-MP Mobile app after confirming it.
        // Do not assume the package ID from the app's display name.
        private const val SAMP_PACKAGE_ID = "REPLACE_WITH_REAL_SAMP_PACKAGE_ID"
        private const val SERVER_IP = "15.235.160.89"
        private const val SERVER_PORT = "62121"
    }

    private lateinit var playerName: EditText
    private lateinit var modsStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
            setBackgroundColor(0xFF17130F.toInt())
        }
        val scroll = ScrollView(this).apply { addView(page) }

        fun text(value: String, size: Float = 16f, color: Int = 0xFFF4EBDD.toInt()) =
            TextView(this).apply {
                text = value
                textSize = size
                setTextColor(color)
                setPadding(0, 8, 0, 8)
            }

        fun button(value: String, action: () -> Unit) =
            Button(this).apply {
                text = value
                setOnClickListener { action() }
            }

        page.addView(text("APSORA RP", 30f, 0xFFD6A84B.toInt()))
        page.addView(text("GRAND THEFT AUTO: SAN ANDREAS • ROLEPLAY", 12f))
        page.addView(text("SERVER", 13f, 0xFFD6A84B.toInt()))
        page.addView(text("$SERVER_IP:$SERVER_PORT", 20f))
        page.addView(button("COPY SERVER ADDRESS") {
            val clip = android.content.ClipData.newPlainText("Server", "$SERVER_IP:$SERVER_PORT")
            (getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(clip)
            Toast.makeText(this, "Server address copied", Toast.LENGTH_SHORT).show()
        })

        page.addView(text("PLAYER NAME", 13f, 0xFFD6A84B.toInt()))
        playerName = EditText(this).apply {
            hint = "Enter your player name"
            setSingleLine(true)
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFFB8AA98.toInt())
            setText(prefs.getString(KEY_PLAYER, ""))
        }
        page.addView(playerName)
        page.addView(button("SAVE PLAYER NAME") {
            prefs.edit().putString(KEY_PLAYER, playerName.text.toString().trim()).apply()
            Toast.makeText(this, "Player name saved in APSORA RP", Toast.LENGTH_SHORT).show()
        })

        page.addView(text("MODS FOLDER", 13f, 0xFFD6A84B.toInt()))
        modsStatus = text("No Mods folder selected.")
        page.addView(modsStatus)
        page.addView(button("SELECT MODS FOLDER") {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
            startActivityForResult(intent, REQUEST_MODS_FOLDER)
        })
        page.addView(button("SCAN MODS FOLDER") { scanModsFolder() })

        page.addView(text("GRAPHICS PRESET", 13f, 0xFFD6A84B.toInt()))
        page.addView(text("Standard: Visual Effects High • Resolution 100% • Draw Distance 80% • Shadows Off • Reflections Low"))
        page.addView(text("LAUNCH GAME", 13f, 0xFFD6A84B.toInt()))
        page.addView(button("OPEN SA-MP MOBILE") { launchSamp() })
        page.addView(text("Note: This launcher does not include the GTA/SA-MP game, inject mods, or automatically send the player name/server to the game."))
        setContentView(scroll)
    }

    private fun scanModsFolder() {
        val uriText = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_MODS_URI, null)
        if (uriText == null) {
            Toast.makeText(this, "Select the Mods folder first", Toast.LENGTH_SHORT).show()
            return
        }
        val folder = DocumentFile.fromTreeUri(this, Uri.parse(uriText))
        if (folder == null || !folder.isDirectory) {
            modsStatus.text = "Folder could not be read. Select it again."
            return
        }
        val entries = folder.listFiles()
        val names = entries.take(30).joinToString("\n") { (if (it.isDirectory) "[Folder] " else "") + it.name }
        modsStatus.text = if (entries.isEmpty()) "Folder is empty." else
            "Found ${entries.size} item(s):\n$names" + if (entries.size > 30) "\n…and more" else ""
    }

    @Deprecated("Deprecated in Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_MODS_FOLDER && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_MODS_URI, uri.toString()).apply()
            modsStatus.text = "Mods folder selected. Tap SCAN MODS FOLDER to list its contents."
        }
    }

    private fun launchSamp() {
        if (SAMP_PACKAGE_ID.startsWith("REPLACE_")) {
            Toast.makeText(this, "SA-MP package ID is not confirmed yet. Set it in MainActivity.kt.", Toast.LENGTH_LONG).show()
            return
        }
        val launchIntent = packageManager.getLaunchIntentForPackage(SAMP_PACKAGE_ID)
        if (launchIntent == null) {
            Toast.makeText(this, "SA-MP Mobile app was not found. Check its package ID.", Toast.LENGTH_LONG).show()
            return
        }
        startActivity(launchIntent)
    }
}
