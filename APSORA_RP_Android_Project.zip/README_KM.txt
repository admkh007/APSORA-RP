APSORA RP — Android Studio starter project

ព័ត៌មានគម្រោង
- ឈ្មោះកម្មវិធី: APSORA RP
- Server: 15.235.160.89
- Port: 62121
- Player Name: រក្សាទុកក្នុង launcher
- Mods: អាចជ្រើសថត និងស្កេន/បង្ហាញឈ្មោះឯកសារ
- Graphics: បង្ហាញការណែនាំកម្រិត Standard

សំខាន់
1. នេះជាគម្រោង Source សម្រាប់ Android Studio មិនមែនជា APK ដែលបាន build រួចទេ។
2. មិនមាន GTA San Andreas ឬ SA-MP client ភ្ជាប់មកជាមួយទេ។
3. Package ID របស់ SA-MP Mobile មិនទាន់បានបញ្ជាក់។ ក្នុង MainActivity.kt សូមកំណត់ SAMP_PACKAGE_ID ទៅ package ID ពិត មុនពេលប្រើប៊ូតុង Open SA-MP Mobile។
4. Player Name និង Server Address បច្ចុប្បន្នត្រូវបានរក្សាទុក/ចម្លងនៅក្នុង launcher ប៉ុណ្ណោះ។ វាមិនទាន់បញ្ជូនស្វ័យប្រវត្តិទៅ SA-MP client ទេ។
5. Mods folder គ្រាន់តែស្កេន និងបង្ហាញបញ្ជីឯកសារ។ វាមិន load ឬ inject .so/native mods ទេ។ កុំបន្ថែម mod ដែលមិនស្គាល់ប្រភព ឬមិនត្រូវគ្នានឹង client។
6. ត្រូវ build និងសាកល្បងលើ Android Studio/ឧបករណ៍ Android មុននឹងចែកចាយ។

របៀបបើក
- បើក Android Studio
- ជ្រើស Open ហើយបើក folder APSORA_RP_Android_Project
- អនុញ្ញាតឱ្យ Gradle sync
- Build > Build APK(s)

កំណត់ package ID
- ស្វែងរក SAMP_PACKAGE_ID ក្នុង MainActivity.kt
- ប្តូរ REPLACE_WITH_REAL_SAMP_PACKAGE_ID ទៅ package ID ពិតរបស់កម្មវិធី SA-MP Mobile
- Build ឡើងវិញ
